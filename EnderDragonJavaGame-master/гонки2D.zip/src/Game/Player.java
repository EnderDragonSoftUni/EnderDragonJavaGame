package Game;

import javax.swing.*;

public class Player {
    public static void testKill() {
        for (int i = 0; i < Main.enemyCount; ++i) {
            if (100 <= Main.xEnemy[i] + 200 && 300 >= Main.xEnemy[i] && Main.yPlayer <= Main.yEnemy[i] + 80 && Main.yPlayer + 80 >= Main.yEnemy[i]) {
                for (int j = 0; j < Main.enemyCount; ++j) {
                    Main.xEnemy[j] = (int) ((Math.random() * 5000) + 5000);
                }
                --Main.health;
                if (Main.health == 0) dead();
            }
        }
    }

    public static void testAddScore() {
        Bonuses.testОбгон();
        Bonuses.testCatchCoin();
        Bonuses.speedBonus();
    }

    private static void dead() {
        Main.dead = true;
        JOptionPane.showMessageDialog(Main.frame, "вы проиграли!", "гонки 2D", JOptionPane.WARNING_MESSAGE);
        Main.xBackGround = 0;
        Main.xPlayer = 0;
        Main.yPlayer = 200;
        Main.speedPlayer = 0;
        Main.health = 3;
        Main.score = 0;
        Main.dead = false;
        Main.go = false;
        Main.stop = false;
        Main.left = false;
        Main.right = false;
        GameLoop.loop();
    }

    public static void movePlayer() {
        Main.xBackGround -= Main.speedPlayer;
        Main.xPlayer += Main.speedPlayer;
        if (Main.go) ++Main.speedPlayer;
        if (Main.stop) --Main.speedPlayer;
        if (Main.left) Main.yPlayer -= Main.speedPlayer / 3 + 3;
        if (Main.right) Main.yPlayer += Main.speedPlayer / 3 + 3;
        if (Main.speedPlayer < 0) Main.speedPlayer = 0;
        if (Main.speedPlayer > 200) Main.speedPlayer = 200;
        if (Main.yPlayer < 50) Main.yPlayer = 50;
        if (Main.yPlayer > 350) Main.yPlayer = 350;
    }
}