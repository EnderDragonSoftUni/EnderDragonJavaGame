package Game;

import javax.swing.*;

public class Main {
    public static Writer writer = new Writer();
    public static JFrame frame = new JFrame("гонки 2D");
    public static int xBackGround = 0;
    public static int xPlayer = 0;
    public static int yPlayer = 200;
    public static int speedPlayer = 0;
    public static int health = 3;
    public static int score = 0;
    public static int обгонTime = 10;
    public static int scoreTime = 30;
    public static final int enemyCount = 4;
    public static int xEnemy[] = new int[enemyCount];
    public static int yEnemy[] = new int[enemyCount];
    public static int speedEnemy[] = new int[enemyCount];
    public static boolean enemyLeft[] = new boolean[enemyCount];
    public static boolean enemyRight[] = new boolean[enemyCount];
    public static int xCoin = (int) (Math.random() * 10000 + 1000);
    public static int yCoin = (int) (Math.random() * 350 + 50);
    public static boolean dead = false;
    public static boolean go = false;
    public static boolean stop = false;
    public static boolean left = false;
    public static boolean right = false;

    private static void startGame() {
        //установка скорости врагов
        for (int i = 0; i < Main.enemyCount; ++i) {
            speedEnemy[i] = (int) (Math.random() * 50 + 10);
        }
        //установка координат врагов
        for (int i = 0; i < Main.enemyCount; ++i) {
            xEnemy[i] = (int) ((Math.random() * 5000) + 5000);
        }
        //рисвание окна
        FrameController.drawFrame();
        //запуск цикла игры
        GameLoop.loop();
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        startGame();
    }
}
