package Game;

public class Enemy {
    public static void moveEnemy() {
        for (int i = 0; i < Main.enemyCount; ++i) {
            Main.xEnemy[i] += Main.speedEnemy[i] - Main.speedPlayer;
            //переустановка переменных врага заехавшего далеко за зону видемости
            if (Main.xEnemy[i] <= -5000 || Main.xEnemy[i] >= 5000) {
                Main.xEnemy[i] = (int) ((Math.random() * 5000) + 1000);
                Main.speedEnemy[i] = (int) (Math.random() * 50 + 10);
            }
            //проверка съезда с дороги врагов
            if (Main.yEnemy[i] < 50) Main.yEnemy[i] = 50;
            if (Main.yEnemy[i] > 330) Main.yEnemy[i] = 330;
            //поворот врагов
            if (Main.enemyLeft[i]) Main.yEnemy[i] -= 5;
            if (Main.enemyRight[i]) Main.yEnemy[i] += 5;
        }
        //повернуть врагов с вероятностью 1 к 10
        if ((int) (Math.random() * 10) == 0) tern();
    }

    private static void tern() {
        for (int i = 0; i < Main.enemyCount; ++i) {
            if ((int) (Math.random() * 2) == 0)
                Main.enemyRight[i] = !Main.enemyRight[i];
            else
                Main.enemyLeft[i] = !Main.enemyLeft[i];
        }
    }
}